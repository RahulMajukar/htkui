// src/pages/Operations/OperationOT1.jsx
export default function OperationOT1() {
  return (
    <div className="p-6">
      <h2 className="text-xl font-bold mb-4">Operation OT1</h2>
      <p>This is the OT1 operation screen for QA F1.</p>
    </div>
  );
}
