import React from "react";

export default function OperationOT3() {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold">Operation OT3</h1>
      <p className="mt-2 text-gray-600">This is Operation OT3 page.</p>
    </div>
  );
}
